import "./inventory.css";
import "./alert.css";
import axios from "axios";
import companyLogo from "./assets/images/company_logo.jpg";
import { useEffect, useRef, useState } from "react";
import "react-date-range/dist/styles.css"; // main style file
import "react-date-range/dist/theme/default.css"; // theme css file
import $ from "jquery";
import "datatables.net-dt";
import ReactDOMServer from "react-dom/server";
// import "rsuite/DatePicker/styles/index.css";

const Inventory = () => {
  const [inventory, setInventory] = useState([]);
  const [filterType, setFilterType] = useState("");
  const [searchText, setSearchText] = useState(""); // State for search text
  const propertyTableRef = useRef(null);

  useEffect(() => {
    // Function to fetch inventory
    const fetchInventory = async () => {
      // alert(searchText);
      try {
        // const response = await axios.get("https://99acres.dreamworld.properties/inventory");
        const response = await axios.get(
          "http://localhost/99acres_api/api/apicommon.php?rentResale=" +
            filterType +
            "&searchString=" +
            searchText,
          {
            params: { rentResale: filterType, searchText: searchText },
          }
        );
        // Update state with fetched inventory
        setInventory(response.data);
        // Destroy the DataTable if it's already initialized
        if ($.fn.DataTable.isDataTable(propertyTableRef.current)) {
          $(propertyTableRef.current).DataTable().destroy();
        }
        $(propertyTableRef.current).DataTable({
          pageLength: 10,
          data: response.data,
          searching: false,
          ordering: true,
          scrollX: true,
          // scrollX: true,
          columns: [
            {
              data: "title",
              className: "text-center align-middle  ",
              render: function (data, type, row) {
                if (type === "display" && data) {
                  const titleElement = (
                    <p
                      className="text-truncate d-inline-block"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        textDecoration: "none",
                        color: "black",
                        maxWidth: "120px",
                      }}
                      data-bs-toggle="tooltip"
                      title={data}
                      data-bs-original-title={data}
                    >
                      {data}
                    </p>
                  );
                  return ReactDOMServer.renderToString(titleElement);
                }
                return data;
              },
            },
            {
              data: "property_type", // Define as Status
              render: function (data, type) {
                // Check if data is available and render accordingly
                if (type === "display" && data) {
                  return ReactDOMServer.renderToString(
                    <div className="text-center">{data}</div>
                  );
                }
                return "N/A";
              },
              className: "text-center align-middle ",
            },
            {
              data: "link",
              className: "link-style text-center align-middle",
              render: function (data, type) {
                if (type === "display" && data) {
                  return ReactDOMServer.renderToString(
                    <a
                      className="text-center"
                      href={data}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ textDecoration: "none", color: "blue" }}
                    >
                      View
                    </a>
                  );
                }
                return data;
              },
            },
            {
              data: "location",
              className: "text-center align-middle  ",
              render: function (data, type) {
                if (type === "display" && data) {
                  const title = (
                    <p
                      className="text-truncate d-inline-block"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        textDecoration: "none",
                        color: "black",
                        maxWidth: "100px",
                      }}
                      data-bs-toggle="tooltip"
                      title={data}
                      data-bs-original-title={data}
                    >
                      {data}
                    </p>
                  );
                  return ReactDOMServer.renderToString(title);
                }
                return data;
              },
            },
            {
              data: "flat_type",
              className: "text-center align-middle",
              render: function (data, type, row) {
                if (type === "display" && data) {
                  const titleElement = (
                    <p
                      className="text-truncate d-inline-block"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        textDecoration: "none",
                        color: "black",
                        maxWidth: "120px",
                      }}
                      data-bs-toggle="tooltip"
                      title={data}
                      data-bs-original-title={data}
                    >
                      {data}
                    </p>
                  );
                  return ReactDOMServer.renderToString(titleElement);
                }
                return data;
              },
            },
            {
              data: "price",
              width: "80px",
              render: function (data, type) {
                // Check if the data is being rendered for display
                if (type === "display" && data) {
                  const cleanedData = data.replace(/[\s,]/g, "");
                  let formattedData = cleanedData;
                  // Replace "Crore" or "crores" with "CR" (case-insensitive)
                  if (cleanedData.match(/crore(s?)/i)) {
                    formattedData = cleanedData.replace(/crore(s?)/i, " Cr");
                  }
                  if (cleanedData.match(/lac(s?)/i)) {
                    formattedData = cleanedData.replace(/lakh(s?)/i, " L");
                  }
                  if (cleanedData.match(/0{3}$/)) {
                    formattedData = cleanedData.replace(/0{3}$/, " K");
                  }
                  return ReactDOMServer.renderToString(
                    <span
                      className="badge bg-success"
                      style={{ fontSize: "14px", fontWeight: "600" }}
                    >
                      {formattedData}
                    </span>
                    // <div className="text-center">{formattedData}</div>
                  );
                }
                return data;
              },
              className: "text-center align-middle",
            },
            {
              data: "price_sqft",
              width: "80px",
              render: function (data, type) {
                // Check if data is available and render accordingly
                if (type === "display" && data) {
                  data = data.replace("/sqft", "");
                  return ReactDOMServer.renderToString(
                    <span
                      className="badge bg-secondary"
                      style={{ fontSize: "14px", fontWeight: "600" }}
                    >
                      {data}
                    </span>
                    // <div className="text-center">{data}</div>
                  );
                }
                return "N/A";
              },
              className: "text-center align-middle",
            },
            {
              data: "total_area",
              className: "text-center align-middle",
            },
            {
              data: "area_type",
              className: "text-center align-middle text-nowrap ",
              render: function (data, type) {
                if (type === "display" && data) {
                  const title = (
                    <p
                      className="text-truncate d-inline-block"
                      // target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        textDecoration: "none",
                        color: "black",
                        maxWidth: "60px",
                      }}
                      data-bs-toggle="tooltip"
                      title={data}
                      data-bs-original-title={data}
                    >
                      {data}
                    </p>
                  );
                  return ReactDOMServer.renderToString(title);
                }
                return data;
              },
            },
            {
              data: "bathroom",
              render: function (data, type) {
                // Check if data is available and render accordingly
                if (type === "display" && data) {
                  return ReactDOMServer.renderToString(
                    <div className="text-center">{data}</div>
                  );
                }
                return "N/A";
              },
              className: "text-center align-middle",
            },
            {
              data: "description",
              className: "text-center align-middle",
              render: function (data, type) {
                if (type === "display" && data) {
                  const title = (
                    <p
                      className="text-truncate d-inline-block"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        textDecoration: "none",
                        color: "black",
                        maxWidth: "150px",
                      }}
                      data-bs-toggle="tooltip"
                      title={data}
                      data-bs-original-title={data}
                    >
                      {data}
                    </p>
                  );
                  return ReactDOMServer.renderToString(title);
                }
                return data;
              },
            },
            {
              data: "possession_by",
              render: function (data, type) {
                // Check if data is available and render accordingly
                if (type === "display" && data) {
                  return ReactDOMServer.renderToString(
                    <div className="text-center">{data}</div>
                  );
                }
                return "N/A";
              },
              className: "text-center align-middle text-nowrap ",
            },
            {
              data: "plot_facing",
              className: "text-center align-middle",
              render: function (data, type) {
                if (type === "display" && data) {
                  const title = (
                    <p
                      className="text-truncate d-inline-block"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        textDecoration: "none",
                        color: "black",
                        maxWidth: "100px",
                      }}
                      data-bs-toggle="tooltip"
                      title={data}
                      data-bs-original-title={data}
                    >
                      {data}
                    </p>
                  );
                  return ReactDOMServer.renderToString(title);
                }
                return data;
              },
            },
            {
              data: "viewed",
              className: "text-center align-middle",
              render: function (data, type) {
                if (type === "display" && data) {
                  const title = (
                    <p
                      className="text-truncate d-inline-block"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        textDecoration: "none",
                        color: "black",
                        maxWidth: "20px",
                      }}
                      data-bs-toggle="tooltip"
                      title={data}
                      data-bs-original-title={data}
                    >
                      {data}
                    </p>
                  );
                  return ReactDOMServer.renderToString(title);
                }
                return data;
              },
            },
            {
              data: "posted_time",
              className: "text-center align-middle",
              render: function (data, type) {
                if (type === "display" && data) {
                  const title = (
                    <p
                      className="text-truncate d-inline-block"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        textDecoration: "none",
                        color: "black",
                        maxWidth: "150px",
                      }}
                      data-bs-toggle="tooltip"
                      title={data}
                      data-bs-original-title={data}
                    >
                      {data}
                    </p>
                  );
                  return ReactDOMServer.renderToString(title);
                }
                return data;
              },
            },
            {
              data: "posted_by",
              className: "text-center align-middle",
              render: function (data, type) {
                if (type === "display" && data) {
                  const title = (
                    <p
                      className="text-truncate d-inline-block"
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        textDecoration: "none",
                        color: "black",
                        maxWidth: "100px",
                      }}
                      data-bs-toggle="tooltip"
                      title={data}
                      data-bs-original-title={data}
                    >
                      {data}
                    </p>
                  );
                  return ReactDOMServer.renderToString(title);
                }
                return data;
              },
            },
            {
              data: "dealer_type",
              render: function (data, type) {
                // Check if data is available and render accordingly
                if (type === "display" && data) {
                  return ReactDOMServer.renderToString(
                    <span className="badge bg-primary">{data}</span>
                    // <div className="text-center">{data}</div>
                  );
                }
                return data;
              },
              className: "text-center align-middle",
            },
          ],
          drawCallback: function () {
            // Reinitialize Bootstrap 5 tooltips after DataTable updates its content
            var tooltipTriggerList = [].slice.call(
              document.querySelectorAll('[data-bs-toggle="tooltip"]')
            );
            var tooltipList = tooltipTriggerList.map(function (
              tooltipTriggerEl
            ) {
              return new bootstrap.Tooltip(tooltipTriggerEl);
            });
          },
          // "initComplete": function () {
          //   var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
          //   var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
          //     return new bootstrap.Tooltip(tooltipTriggerEl);
          //   });
          // }
        });
      } catch (error) {
        console.error("There was an error fetching the Inventory", error);
      }
    };
    // Call the fetchinventory function on component mount
    fetchInventory();
  }, [filterType, searchText]);

  const handleRentAndResaleButton = (e) => {
    setFilterType(e.target.value);
    // const selectedValue = e.target.value;
    // // Now you have the value of the selected radio button
    // console.log(selectedValue);
    // alert('Button clicked');
  };

  const handleSearch = (e) => {
    setSearchText($("#txtSearch").val());
  };

  const handleClearFilters = () => {
    // Clear all filters
    setFilterType("");
    setSearchText("");
  };

  return (
    <div className="list_page full_page">
      <div className="vl_loader-wrapper d-none loaderHideShow">
        <div className="vl_loader"></div>
      </div>
      <header className="shadow-sm py-3 mb-4 border-bottom">
        <div className="container-fluid px-md-5">
          <div className="d-flex flex-column flex-md-row align-items-center justify-content-between">
            <a
              href="dashboard"
              className="d-flex align-items-center text-dark text-decoration-none"
            >
              <img
                src={companyLogo}
                width="120"
                className="img-fluid"
                alt="logo"
              />
            </a>
            <div className="d-flex align-items-center justify-content-center flex-grow-1 header_title">
              <div className="d-flex align-items-center gap-2">
                <h4 className="text-uppercase fs-6 text-center fw-bold mb-0">
                99Acres Inventory
                </h4>
              </div>
            </div>
            <div className="border-start ps-3 ms-2 d-flex align-items-center">
              {/* <div className="user_wrapper me-2">
                <h2 className="text-uppercase">p</h2>
                <p className="text-capitalize">Welcome -</p>
              </div> */}
              <a href="logout.php" className="btn btn-outline-danger btn-sm">
                <span className="me-2">
                  <i className="fa-solid fa-arrow-right-from-bracket"></i>
                </span>{" "}
                Logout
              </a>
            </div>
          </div>
        </div>
      </header>
      <nav aria-label="breadcrumb">
        <ol
          className="breadcrumb my-2 text-center small justify-content-center"
          id="breadcrumb2"
        >
          <li className="breadcrumb-item">
            <a href="/dashboard" className="text-capitalize">
              {" "}
              <span>
                <i className="fa-solid fa-house"></i>{" "}
              </span>{" "}
              {"dashboard"}
            </a>
          </li>
          <li className="breadcrumb-item active" aria-current="page">
            <a href="#" className="text-capitalize">
              {" "}
              99Acres Inventory
            </a>
          </li>
        </ol>
      </nav>
      <div className="container-fluid px-md-5 mt-4">
        <main>
          <div className="card">
            <div className="card-header bg-transparent text-start">
              <div className="d-flex justify-content-between align-items-center flex-md-row flex-column">
                <div className="d-flex gap-2 search_wrapper ">
                  <div className="search-input">
                    <span className="icon">
                      <i className="fas fa-search"></i>
                    </span>
                    <input
                      type="text"
                      className="form-control"
                      id="txtSearch"
                      name="txtSearch"
                      placeholder="search"
                    />
                  </div>
                  <button
                    className="btn btn-primary btnSearch btn-sm"
                    onClick={handleSearch}
                  >
                    <span className="me-2">
                      <i className="fa-solid fa-magnifying-glass"></i>
                    </span>
                    Search
                  </button>
                  <button
                    className="btn btn-outline-danger mt-md-0 mt-2"
                    onClick={handleClearFilters}
                  >
                    Clear all Filter
                  </button>
                </div>
                <a href="/uploadExcel" className="btn btn-outline-primary "><span><i class="fa-solid fa-cloud-arrow-up"></i></span> Upload file</a>
              </div>
            </div>
            <div className="card-body ">
              <div className="top_filter  py-3 px-3 d-flex flex-column gap-2">
                <div className="d-flex justify-content-md-start justify-content-start flex-wrap gap-2">
                  <div className="ms-md-3 d-flex gap-2 align-items-center flex-wrap">
                    <label className="small">Room</label>
                    <div className="d-flex gap-2">
                      <div className="d-inline">
                        <input
                          className="form-check-input rd_chip_input"
                          type="radio"
                          name="chk_room_type"
                          id="rdbhk_1"
                          value="Resale"
                          checked={filterType === "Resale"}
                          hidden
                          onChange={handleRentAndResaleButton}
                        />
                        <label className="rd_chip_tag" htmlFor="rdbhk_1">
                          Resale
                        </label>
                      </div>
                      <div className="d-inline">
                        <input
                          className="form-check-input rd_chip_input"
                          type="radio"
                          name="chk_room_type"
                          id="rdbhk_2"
                          value="Rent"
                          checked={filterType === "Rent"}
                          hidden
                          onChange={handleRentAndResaleButton}
                        />
                        <label className="rd_chip_tag" htmlFor="rdbhk_2">
                          Rent
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
          
              </div>
              <div className="d-flex gap-2 flex-column flex-md-row mt-4">
                <div className="table-responsive  flex-10 table_wrapper">
                  <table
                    className="table table-hover border mb-0 small cell-border display w-100"
                    ref={propertyTableRef}
                  >
                    <thead className="bg-light ">
                      <tr>
                        <th scope="col" style={{ width: "150px" }}>Title</th>
                        <th scope="col">Status</th>
                        <th scope="col">Link</th>
                        <th scope="col">Location</th>
                        <th scope="col">Flat Type</th>
                        <th scope="col">Price</th>
                        <th scope="col">Price/Sqft</th>
                        <th scope="col" style={{ width: "150px" }}>Total Area</th>
                        <th scope="col">Area Type</th>
                        <th scope="col">Bathroom</th>
                        <th scope="col">Description</th>
                        <th scope="col">Status</th>
                        <th scope="col">Facing</th>
                        <th scope="col">Viewes</th>
                        <th scope="col">Posted on</th>
                        <th scope="col">Posted By</th>
                        <th scope="col">Dealer</th>
                        {/* <th scope="col">Created Date</th>
                        <th scope="col">Modified Date</th> */}
                      </tr>
                    </thead>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Inventory;
